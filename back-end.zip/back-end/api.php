<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Requested-With, Accept');
// 连接到MySQL数据库
$servername = "localhost";  // MySQL服务器地址
$username = "root";  // MySQL用户名
$password = "123456";  // MySQL密码
$dbname = "calculator";  // 数据库名

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("连接数据库失败: " . $conn->connect_error);
}

// 处理POST请求
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取POST数据
    $data1 = $_POST['data1'];
    $data2 = $_POST['data2'];

    // 准备要执行的SQL语句
    $sql = "INSERT INTO cal (cur, res) VALUES ('$data1', '$data2')";

    // 执行SQL语句
    if ($conn->query($sql) === TRUE) {
        echo "数据保存成功";
    } else {
        echo "保存数据时出错: " . $conn->error;
    }
}
// 处理GET请求
elseif ($_SERVER["REQUEST_METHOD"] == "GET") {
    // 检查是否存在num参数
    if (isset($_GET['num'])) {
        $num = $_GET['num']-1;

        // 准备要执行的SQL语句
        $sql = "SELECT * FROM cal ORDER BY id DESC LIMIT $num, 1";

        // 执行SQL语句并获取结果
        $result = $conn->query($sql);

        // 将结果转换为关联数组并以JSON格式返回
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
    }
}

// 关闭数据库连接
$conn->close();
?>